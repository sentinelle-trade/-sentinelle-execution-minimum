def verifier_signal():
    return {"actif": "TEST/USDT", "direction": "LONG", "prix": 123.45, "type_signal": "TEST", "commentaire": "Démo IA"}
